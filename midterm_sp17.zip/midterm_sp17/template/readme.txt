compile:

    g++ template.cpp -o template -std=c++11
    g++ cin_fscanf.cpp -o cin_fscanf -std=c++11

run:
    
    ./template input01.txt
    ./cin_fscanf < input_all.txt
