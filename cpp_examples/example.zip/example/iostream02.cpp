#include <iostream>
using namespace std;
 
int main() {
	int x, y;
	cout << "Please enter 2 numbers: ";
	cin >> x >> y;
	cout << x << "+" << y << "=" << x+y << endl;
	cin.get();
	return 0;
}
