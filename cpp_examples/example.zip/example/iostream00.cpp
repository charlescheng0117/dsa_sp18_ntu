#include <stdio.h>
#include <iostream>	// A "preprocessor" directive that tells the compiler to put code from the header "iostream" into our program before creating the executable
 
int main() {
	printf("This printing is based on C-style printf()!\n");
	std::cout << "This printing is based on C++ iostream!\n";
}
