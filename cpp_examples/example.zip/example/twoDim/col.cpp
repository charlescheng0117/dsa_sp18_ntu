#include "matrixSum.cpp"

int main(){
  printf("%d\n", colSum(myArray));
  return 0;
}
