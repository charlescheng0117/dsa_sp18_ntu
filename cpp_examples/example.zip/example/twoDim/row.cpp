#include "matrixSum.cpp"

int main(){
  printf("%d\n", rowSum(myArray));
  return 0;
}
