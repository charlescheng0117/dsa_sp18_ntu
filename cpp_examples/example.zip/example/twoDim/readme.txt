Two ways to compute matrix summation

Makefile: This is the make file for unix/linux
