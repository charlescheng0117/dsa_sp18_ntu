// My first C++ program

#include <cstdlib>
#include <iostream>

int main(){
	std::cout << "Hello world!" << std::endl;
	return EXIT_SUCCESS;
}
