// My first C++ program

#include <cstdlib>
#include <iostream>
using namespace std;		// makes std:: available

int main(){
	cout << "Hello world!" << endl;		// std:: is not needed
	return EXIT_SUCCESS;
}
