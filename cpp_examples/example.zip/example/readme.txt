How to compile via g++:

1. Add path ==> PATH=$PATH:/mnt/d/users/jang/batch
2. Compile and test ==> cppTest.sh hello00



How to compile via vc:
cppTest.bat hello00

How to compile via devCpp:
devCppTesg.bat hello00
